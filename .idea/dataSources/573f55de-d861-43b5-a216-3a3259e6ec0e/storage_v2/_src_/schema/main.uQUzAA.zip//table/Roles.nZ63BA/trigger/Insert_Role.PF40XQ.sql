CREATE TRIGGER Insert_Role
BEFORE INSERT ON Roles 
 WHEN new.id NOT IN ( SELECT id FROM Workers W
            WHERE W.id=New.id IS NOT NULL )
BEGIN
   SELECT Raise (ABORT,'Person cannot be Student and Teacher at the same time');
END;

